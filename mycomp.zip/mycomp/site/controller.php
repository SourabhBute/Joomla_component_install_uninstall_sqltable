<?php 
defined('_JEXEC') or die("Access Deny");

class MyCompController extends JControllerlegacy

{            

      function display($cachable = false, $urlparams = false){

      	echo "I am Without task";
      }


       function create(){

         $doc=JFactory::getDocument();
         $doc->addStyleSheet(JURI::root().'media/com_mycomp/css/frontend_create_task.css');
         $doc->addScript(JURI::root().'media/com_mycomp/js/frontend_create_task.js');


       	echo '<div id="welcome">welcome to create</div>';
       }


      function delete(){

      	 $app=JFactory::getApplication();

          $id=JRequest::getVar('id');
          
          echo "you want to delete $id";

          $app->close();


      }

       function  edit()
        {
           echo "Edit Function called";

        }



}





?>