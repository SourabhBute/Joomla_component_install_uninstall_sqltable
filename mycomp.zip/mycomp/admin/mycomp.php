<?php 

defined('_JEXEC')or die("access deny");

//echo "<h3>Welcome to Mycom Backend</h3>";

$controller =JControllerLegacy::getInstance("MyComp");

$input=JFactory::getApplication()->input;

$controller->execute($input->getCmd('task'));

$controller->redirect();




?>