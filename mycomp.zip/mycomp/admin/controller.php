<?php 
defined('_JEXEC') or die("Access Deny");

/**
 * 
 */
class MyCompController extends JControllerLegacy
{
	function display($cachable = false, $urlparams = array()){

		JToolBarHelper::Title('My Component');
        echo JText::_("COM_MYCOMP_WELCOME_MESSAGE");
	}
	function create()
	{   $doc=JFactory::getDocument();
		$doc->addStyleSheet(JURI::root().'media/com_mycomp/css/backend_create_task.css');

		$doc->addScript(JURI::root().'media/com_mycomp/js/backend_create_task.js');
             

		JToolBarHelper::Title('Create New Task');

		 $db=JFactory::getDBO();
		 $query="INSERT INTO #__mycomp_posts(title,body) VALUES('FIRST POST','THIS IS FIRST POST') ";
         
         $db->setQuery($query);

         $db->query();



		echo '<div class="welcome">'.JText::_("COM_MYCOMP_CREATE_TASK").'</div>';
		
	}

	function delete()
	{

      echo JText::_("COM_MYCOMP_DELTE_TASK");
	}

	function listtask()
	{  JToolBarHelper::Title('List All Task');
       echo JText::_("COM_MYCOMP_LIST_TASK","list");

	}

    function help()
    {   JToolBarHelper::Title('Help Documentation');
    	echo JText::_("COM_MYCOMP_HELP_TASK");

    	echo '<h1>This is help task <input type="text">';
    }
}



?>